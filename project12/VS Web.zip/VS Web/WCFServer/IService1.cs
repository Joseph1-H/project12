﻿using Model;
using System.ServiceModel;

namespace WCFServer
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        //====================================================== 
        // Admins 
        // ===================================================== 
        [OperationContract]
        AdminsList AdminsSelectAll();
        [OperationContract]
        AdminsRec AdminsSelect(long id);
        [OperationContract]
        bool AdminsInsert(AdminsRec admin);
        [OperationContract]
        bool AdminsUpdate(AdminsRec admin);
        [OperationContract]
        bool AdminsDelete(long id);
        //[OperationContract]
        // UserLogged AdminsInsertWithPassword(AdminsRec admin, PasswordsRec password);



        //====================================================== 
        // Comments 
        // ===================================================== 
        [OperationContract]
        CommentsList CommentsSelectAll();
        [OperationContract]
        CommentsRec CommentsSelect(long id);
        [OperationContract]
        bool CommentsInsert(CommentsRec Comment);
        [OperationContract]
        bool CommentsUpdate(CommentsRec Comment);
        [OperationContract]
        bool CommentsDelete(long id);
        //[OperationContract]
        // UserLogged CommentsInsertWithPassword(CommentsRec Comment, PasswordsRec password);

        //====================================================== 
        // Exercises 
        // ===================================================== 
        [OperationContract]
        ExercisesList ExercisesSelectAll();
        [OperationContract]
        ExercisesRec ExercisesSelect(long id);
        [OperationContract]
        bool ExercisesInsert(ExercisesRec Exercise);
        [OperationContract]
        bool ExercisesUpdate(ExercisesRec Exercise);
        [OperationContract]
        bool ExercisesDelete(long id);
        //[OperationContract]
        // UserLogged ExercisesInsertWithPassword(ExercisesRec Exercise, PasswordsRec password);

    }
}

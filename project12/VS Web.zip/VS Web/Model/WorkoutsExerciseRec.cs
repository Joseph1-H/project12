﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class WorkoutsExerciseRec : BaseEntity
    {
        public long WorkoutID { get; set; }
        public long ExerciseID { get; set; }
    }
}
